<?php
                $usesmiles = 1;

                $allowbbcode = 1;

                $allowhtml = 0;

        ?>