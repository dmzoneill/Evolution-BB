###########################################################################
################## evoBB version 0.3 alpha ################################
################################# README ##################################

Release alpha 0.3 is experimental and is not stable or bug free.
There are still things to be done before a 'stable' release is near.
When you find a bug please use our bug tracking system http://www.evobb.com
to report it.  Also, because of the prematurity of the code, parts are
perhaps not as pretty or efficient as they should be.  This too will be
corrected as soon as we have time.
If you find part of the code that you think needs to be changed or
for which you have a more efficient way of coding please visit the
site and report it.  We will have a suggestions database as well as a bug
tracking database for this purpose.  If we do incorporate some of your code
into the system we will give you credit for it.

NOTE: We would like to apoligise for the delay on this release. Infact it was
a huge delay but as you are probally aware EvoBB is developed by a small team
of programmers in their spare time, and that has been like golddust recently.
We'll try to be a little more effeicent in the future.

KNOWN ISSUES: We are aware that the Java chat applett is broken, this will
be resolved this week and a patch released.


############################## HOWTO INSTALL ###############################

The 0.3 release features a brand new, easy, installation process for all you
users. You should start with running the setup executable in forum/install 
first. (Setup.exe for win32, unix for *nix). This will aid you to configure
connect.php(3). Of course you may do this manually if you wish.
Next upload the contents of 'forum' to your webserver and surf to: 
'http://mywebserver.com/install/'. This will load the installation scripts
and install evoBB for you. That's all folks! MAKE SURE YOU DELETE THE
'install' DIRECTORY ONCE YOU HAVE INSTALLED EVOBB SUCCESSFULLY. IT COULD LEAD
TO THE COMPRIMISE OF YOUR FORUM.

enjoy evoBB 0.3 ;)


##########################     DEVELOPERS  ##################################

Martin Galpin aka f0d -> EvoBB Lead Programmer
Contact: f0d@evobb.com

Kris Bailey aka xavic -> EvoBB Support Programmer
Contact: xavic@evobb.com

David O'Neill aka NEILLER -> EvoNews + EvoGB + webmaster + EvoBB
Contact: neiller@evobb.com

Ashley Williams aka h0stile -> Head Designer
Contact: h0stile@evobb.com

Ren Jin aka notiboy -> does the fan logo/banners and flash. Useless actually.
Contact:

Alexis Mancini -> does the graphics.
Contact: mancini@evobb.com

Steven Pignataro -> does the graphics.
Contact: secretsteve@evobb.com

NightHalk -> Lead Tester.
Contaxt: nighthalk1980@hotmail.com


################################# LICENSE #################################

evoBB is free software that you may download and use.  You may modify this
code as much as you like but you may not re-distribute it.  We wish for
this software to be free but we do not wish to have it distributed by
anyone other than the evobb team.  You may not sell evobb software but you
may sell the service of installing and/or configuring it.  If you do sell
the service of installing and/or configuring evobb software you must
inform whomever is employing you for this service that evobb is free and
that they are not paying for evobb but for your service.

And as is with GNU licensed software this software (evoBB) does not come
with any warranty whatsoever, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. (sound framiliar?)

##########################################################################

############################# CREDIT #####################################

The files off.gif and on.gif in use on fdisplay.php are originally part of an
IconPackager theme, Block OS HangOn. Much credit to the creators of the icon.
Below is the email and website of the people who made it.
LineSudio Email: block@m10.alpha-net.ne.jp
LineStudio Website: URL:http://block.m78.com/

##########################################################################

