<?php
 $host = "localhost"; /* THE HOST WHERE THE DATABASE IS */
 $username = ""; /* DATABASE USERNAME */
 $password = ""; /* DATABASE PASSWORD */
 $db_name = ""; /*DATABASE NAME */
 $db_type = "mysql"; /*DATABASE TYPE */

$lang = "english";
 $dirname = "forum";

/****  DON'T EDIT BELOW *****/
include($path."db_".$db_type.".php");
include($path. "languages/" .$lang.".php.inc");
$stream = new db;
$stream->connect();
