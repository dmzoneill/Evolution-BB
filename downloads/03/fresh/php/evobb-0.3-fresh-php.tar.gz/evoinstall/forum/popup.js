function BrWindow(theURL,winName) { 
  		window.open(theURL,winName,'width=200,height=70');
	}
