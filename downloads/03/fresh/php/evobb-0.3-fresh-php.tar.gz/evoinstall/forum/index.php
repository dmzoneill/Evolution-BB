<html><head><title>Evolution BB</title></head>
<body>
<?php $var = uniqid(0); ?>
<a href="fdisplay.php?<?php echo $var; ?>">Goto Forums</a>
<script language=javascript>

<!--

setTimeout("document.location.href='fdisplay.php?<?php echo $var; ?>';", 100);

//-->

</script>
</body>
</html>