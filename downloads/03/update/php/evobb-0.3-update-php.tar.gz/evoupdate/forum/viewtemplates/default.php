3

<table width="100%">

  [begin]

  <tr bgcolor=[bg]>

        <td width=15% valign=top>[username]<br>

        <font size=-1>[title]</font><br>

        [stars]<br>

        <font size=-1>[postcount]

        <br>

        [awards]

        <br>

        [views]</font>

        <br>

        <br>

        [linkmenow]

        </td>



    <td align=left valign=top width="80%">

      <table border=0 width=100%>

        <tr>

          <td> <img src="images/posticon.gif"> [posted]<br>

          </td>

        </tr>

        <tr>

          <td>

            <hr width=98% noshade>

            [post]

            [signiture]

            </td>

        </tr>

      </table>

    </td>

    <td width="5%" valign=top align=center>

      <table border="0" cellspacing="0" cellpadding="0" width="100%">

        <tr>

          <td>[editpost] <br>

            [pmlink] <br>

            [replylink] </td>

        </tr>

      </table>

    </td>

        </tr>

[end]

</table>

