1
<table border="0" cellspacing="1" cellpadding="2">
[begin]
  <tr bgcolor=[bg]>
    <td>
      <table width="100%" border="0" cellspacing="1" cellpadding="2">
        <tr>
          <td width="20%">[username] </td>
          <td width="17%"><font size=-1>[title]</font></td>
          <td width="14%">[stars]</td>
          <td width="17%"><font size=-1>[postcount] </font></td>
          <td width="17%"><font size=-1>[awards] </font></td>
          <td width="15%"><font size=-1>[views]</font> </td>
        </tr>
      </table>
      
    </td>
  </tr>
  <tr bgcolor=[bg]>
    <td>
      <table border=0 width=100%>
        <tr>
          <td> <img src="images/posticon.gif"> [posted] </td>
        </tr>
        <tr>
          <td> 
            <hr width=98% noshade>
            [post] </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr bgcolor=[bg]>
    <td>[linkmenow] [editpost] [pmlink] [replylink] </td>
  </tr>
[end]
</table>

