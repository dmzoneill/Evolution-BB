6

<table border=0>
[beginheader]
<tr>
        <td colspan=6 bgcolor="[headerbg]" width=*><center>[newslabel]</center></td>
</tr>
<tr>
        <td colspan=6 bgcolor="[regbg]"> [newsfader] </td>
</tr>

                 <tr>

                 <td bgcolor="[headerbg]" width=15>&nbsp;</td>

                     <td width="60%" bgcolor="[headerbg]">[forum]</td>

                     <td width="7%" bgcolor="[headerbg]">[posts]</td>

                     <td width="7%" bgcolor="[headerbg]">[topics]</td>

                     <td width="7%" bgcolor="[headerbg]">[views]</td>

                     <td width="19%" bgcolor="[headerbg]">[lastpost]</td>

                 </tr>

                 [endheader]



[begingroup]

                 <tr bgcolor="[headerbg]">

                     <td  align=center colspan=6>[groupname]</td>

                 </tr>

[endgroup]



[beginforum]

                <tr>

                    <td width=15 bgcolor="[regbg]">[folderlink]</td>

                    <td bgcolor="[regbg2]">[textlink]&nbsp;&nbsp;[threadedlink]

                                          <br><b> - </b> <font size=-1>[description]<br>[moderators][forumtype][rules]</font></td>

                    <td align=center bgcolor="[regbg2]">[thisposts]</td>

                    <td  align=center bgcolor="[regbg2]">[thistopics]</td>

                    <td  align=center bgcolor="[regbg2]">[thisviews]</td>

                    <td  align=right bgcolor="[regbg]">[lastpostdate]<br>[lastpostby]</td>

               </tr>

[endforum]