<?php
echo getenv('QUERY_STRING');
?>
