
<?php


/* 
EvoGB written by neiller at evobb dot com (neiller@evobb.com)

Also available EvoBB and EvoNews co-producer with Xavic and fod 
available for download @ http://www.evobb.com...

Note: you can edit below this but its not advised unless asked to do so
No nead to delete install.php after an install

Make sure to edit the connect.php before you start installing your EvoGB :)

NB : once logged in change your password :)

If you wish to make contributions / changes to the Evolution Products
do so and send what you have done with explanations to webmaster@evobb.com
*/



?>



<script language=javascript>
<!---
function xeroxsmile () {
return;
}

function smile(add) {
	var revisedpost;
	var currentpost = document.entry.message.value;
	revisedpost = currentpost+add;
	document.entry.message.value=revisedpost;
	document.entry.message.focus();
	return;
}
function image(){
var imgsrc = prompt("Please enter the url of the image:", "http://www.yoursite.com/fods-ass.gif")
document.entry.message.value+=":img:" + imgsrc +":/img:";
}
function bold(){
var imgsrc = prompt("Enter your message:", "hello world")
document.entry.message.value+=":b:" + imgsrc +":/b:";
}
function italic(){
var imgsrc = prompt("Enter your message:", "Hello World")
document.entry.message.value+=":i:" + imgsrc +":/i:";
}
function underline(){
var imgsrc = prompt("Enter your message:", "Hello world")
document.entry.message.value+=":u:" + imgsrc +":/u:";
}

function br(){
document.entry.message.value+=":br:";
}

function h(){
var imgsrc = prompt("Enter your message:", "Hello world");
var hsize = prompt("Enter your heading size 4-6 :", "4");
document.entry.message.value+=":h" + hsize + ":" + imgsrc + ":/h" + hsize + ":";}


//--->
</script>


<a href="javascript:bold();">
<image src='images/bold.gif' border='0' alt='bold'></a>

<a href="javascript:italic();">
<image src='images/italic.gif' border='0' alt='italic'></a>

<a href="javascript:underline();">
<image src='images/underline.gif' border='0' alt='Underline'></a>

<a href="javascript:image();">
<image src='images/image.gif' border='0' alt='Insert Iamge'></a>

<a href="javascript:h();">
<image src='images/fontcol.gif' border='0' alt='Heading size'></a>

<a href="javascript:br();">
<image src='images/br.gif' border='0' alt='line break'></a>



<br>


<A onclick="smile(' :wtf: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/indifferent.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' :msn: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/dood.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' :confused: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/confused.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' }: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/icon_smile_evil.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' :rolleyes: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/rolleyes.gif" width=15 border=0></A>

<A onclick="smile(' :clown: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/icon_smile_clown.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' B) ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/icon_smile_blackeye.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' :8: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/icon_smile_8ball.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' xx) ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/icon_smile_dead.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' :y: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/icon_smile_approve.gif" width=15 border=0></A>

<A onclick="smile(' :bean: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/beansmile.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' :) ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Smile src="./images/smiles/icon_smile.gif" width=15 border=0></A>&nbsp;
 
<A onclick="smile(' :sad: ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=sad src="./images/smiles/frown.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' :D ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt="Big Grin" src="./images/smiles/icon_smile_big.gif" width=15 border=0></A>&nbsp; 

<A onclick="smile(' ;) ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Wink src="./images/smiles/icon_smile_wink.gif" width=15 border=0></A>
<A onclick="smile(' :p ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Razz src="./images/smiles/icon_smile_tongue.gif" width=15 border=0></A>&nbsp;

<A onclick="smile(' 8) ');" href="javascript:%20xeroxsmile()">
<IMG height=15 alt=Cool src="./images/smiles/icon_smile_cool.gif" width=15 border=0></A>&nbsp; 






	