<?php

require('auth.php');

$thistitle = "Administrate Forums";
include('header.php');

switch ($do) {



######################################
######## add new forum here ##########
######################################



case "addnew":



//first off insert the descriptoins and mods etc into evo_forums

$mods = implode("|", $mods);

if ($group=="sub"){

if ($subforumid=="not"){
die("must select a forum for this to be a subforum for!");
} else {
$group = $subforumid;
$sub = "1";
}

} else {
$sub="0";
}

$result = $stream->do_query("insert into evo_forums (auto, fgroup, title, description, mods, last, sub) values ('', '$group', '$forum_name', '$forum_description', '$mods', '', '$sub')", "one");

//now we must make the tables so that posts etc can be stored

$var = intval($stream->do_query("select auto from evo_forums where fgroup='$group' && title='$forum_name' && description='$forum_description'", "one"));

//now we make the rest of the tables

$result = $stream->do_query("CREATE TABLE evo_topics_$var (
   topic_id int(11) DEFAULT '0' NOT NULL auto_increment,
   topic_subject varchar(255) NOT NULL,
   poster_id int(11) DEFAULT '0' NOT NULL,
   time bigint(255) unsigned DEFAULT '0' NOT NULL,
   audience int(2) DEFAULT '0' NOT NULL,
   views bigint(100) unsigned DEFAULT '0' NOT NULL,
   icon int(1) DEFAULT '0' NOT NULL,
   pollid int(11) DEFAULT '0' NOT NULL,
   readit blob NOT NULL,
   closed int(1) DEFAULT '0' NOT NULL,
   PRIMARY KEY (topic_id),
   KEY topic_id (topic_id),
   UNIQUE topic_id_2 (topic_id)
)

", "one");

$result = $stream->do_query("CREATE TABLE evo_posts_$var (
   topic_id bigint(255) unsigned DEFAULT '0' NOT NULL,
   post_id bigint(255) unsigned DEFAULT '0' NOT NULL auto_increment,
   poster_id int(11) DEFAULT '0' NOT NULL,
   post blob NOT NULL,
   time bigint(255) unsigned DEFAULT '0' NOT NULL,
   something tinyint(4) DEFAULT '0' NOT NULL,
   notify int(1) DEFAULT '0' NOT NULL,
   ip varchar(100) DEFAULT '0.0.0.0' NOT NULL,
   sig int(1) DEFAULT '0' NOT NULL,
   PRIMARY KEY (post_id),
   KEY post_id (post_id),
   UNIQUE post_id_2 (post_id)
)", "one");

echo "Forum created Succesfully. Click <a href=\"admin_forums.php\">here</a> to return to forum admin.";

break;



################################

######edit forum here###########

################################



case "editforum":

if ($stream->do_query("select sub from evo_forums where auto = '$id'", "one")>0){
$sub = "yes";
} else {
$sub = "no";
}

$result = $stream->do_query("select * from evo_forums where auto = '$id'", "row");

$id = $result[0];

$group = $result[1];

$title = $result[2];

$description = $result[3];

$mods = $result[4];

$last = $result[5];
//get all the groups

$result = $stream->do_query("select * from evo_groups", "array");

?>

<form method="post" action="admin_forums.php?do=doedit&id=<?php echo $id; ?>">

<table border=0>

<tr>

<td><b>ID:</b></td>

<td><?php echo $id; ?></td>

</tr>

<tr>

<td><b>Group:</b></td>

<td><select name="group">
<?

for ($x=0; $x<count($result); $x++) {

if ($sub=="no"){
if ($result[$x][0]==$group){
$extra = " selected";
} else {
$extra = "";
}
}
echo "<option value=\"".$result[$x][0]."\"$extra>".$result[$x][0]." - ".$result[$x][1]."</option>";

}

?>
<option value="sub"<?php if ($sub=="yes"){echo " selected";}?>>Subforum, its parent is:</option>
</select><br>
<select name=subforumid>
<?php
$allforums = $stream->do_query("select auto, title from evo_forums order by auto ASC", "array");

for ($x=0; $x<count($allforums); $x++){
$thistitle = rawurldecode($allforums[$x][1]);
$thisid = $allforums[$x][0];

if ($sub=="yes" && $group==$thisid){
echo "<option value=$thisid selected>$thistitle</option>\n";
} else {
echo "<option value=$thisid>$thistitle</option>\n";
}

}
?>
<option value="not"<?php if ($sub=="no"){echo " selected";}?>>Not a Subforum</option>
</select>
</td>

</tr>

<tr>

<td><b>Forum Title:</b></td>

<td><input type="text" name="title" value="<?php echo $title; ?>" size="10"></td>

</tr>

<tr>

<td><b>Forum Description:</b></td>

<td><input type="text" name="description" value="<?php echo $description; ?>" size="20"></td>

</tr>

</table>

<input type=hidden name=id value="<?php echo $id; ?>">
<input type=hidden name=mods value=$mods>
<input type=hidden name=last value=$last>
<input type=submit value="Update">
 &nbsp; <a href="admin_forums.php?do=delete&id=<?php echo $id; ?>">Delete Forum</a> (Warning all posts will be lost).
<?

break;


case "doedit":
###########################################
########actually update the forum##########
###########################################
if ($group=="sub"){

if ($subforumid=="not"){
die("must select a forum for this to be a subforum for!");
} else {
$group = $subforumid;
$sub = "1";
}

} else {
$sub="0";
}


$result = $stream->do_query("UPDATE evo_forums SET fgroup = '$group', title = '$title', description = '$description', sub = '$sub' where auto = '$id'", "one");
if($result!="bad") {
echo "Forum $title updated.";
?>
<script language=javascript>
<!--
setTimeout("document.location.href='admin_forums.php?<?php echo uniqid(0);?>';", 2000);
//-->
</script>
<?
} else {
echo "Error updating forum";
}
break;


case "delete":

if(!intval($id)) {
die(); //because if this is set to auto it can delete all forums.
}

#delete all existance
$result = $stream->do_query("delete from evo_forums where auto = '$id'", "one");
echo "<b>Deleted entry from evo_forums&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ <font color=green>OK</font> ]<br>\n</b>";
$result = $stream->do_query("drop table evo_posts_$id", "one");
echo "<b>Deleted posts table evo_posts_$id&nbsp;&nbsp;&nbsp;[ <font color=green>OK</font> ]<br>\n</b>";
$result = $stream->do_query("drop table evo_topics_$id", "one");
echo "<b>Deleted topics table evo_topics_$id [ <font color=green>OK</font> ]<br>\n</b>";
break;





#################################

######## default ################

################################



default:

#get the current groups

$result = $stream->do_query("select * from evo_groups", "array");

?>

<form method="post" action="admin_forums.php?do=addnew" name="new">



<table border=0 width=500>

<tr>

<td colspan=2>From here you can add new forums to your BB or edited existing ones.<br>New Forum:</td>

</tr>

<tr>

<td align=right>Forum Title:</td>

<td><input type="text" name="forum_name" size="20"></td>

</tr>

<tr>

<td align=right>Put This Forum in:</td>

<td><select name="group">

<?

for ($i=0; $i<count($result); $i++) {

echo "<option value=".$result[$i][0].">".rawurldecode($result[$i][1])."</option>";

}

?>
<option value="sub">Make This Forum a Subforum of:</option>
</select><br>
<select name=subforumid>
<?php
$allforums = $stream->do_query("select auto, title from evo_forums order by auto ASC", "array");

for ($x=0; $x<count($allforums); $x++){
$thistitle = rawurldecode($allforums[$x][1]);
$thisid = $allforums[$x][0];
echo "<option value=\"$thisid\">$thistitle</option>\n";
}
?>
<option value="not" selected>Not a Subforum</option>
</select></td>

</tr>

<tr>

<td align=right>Forum Description:</td>

<td><input type="text" name="forum_description" size="40"></td>

</tr>

<tr>

<td align=right>Moderators:<br>(check all mods for the new forum)</td>

<td><?

$result = $stream->do_query("select username, id from evo_users where rank > 2", "array");

for ($i=0; $i<count($result); $i++) {

echo "<input type=\"checkbox\" name=\"mods[]\" value=\"".$result[$i][1]."\"> - ".$result[$i][0]."<br>";

}

?>

</select></td>

</tr>

<tr>

<td align=right>Make Forum?</td>

<td><input type=submit value="Add Forum"></td>

</tr>

</table>

</form>



<br><br>



Existing forums:<br>

<?

$result = $stream->do_query("select auto,title,description from evo_forums", "array");

?>

<table border=0 width=100%>

<tr>

<td width=30><b>ID</b></td>

<td><b>Forum Title</b></td>

<td><b>Description</b></td>

</tr>

<?

#first off all we will need to look up the mods ids so that we can return a name not id.


for ($i=0; $i<count($result); $i++) {

echo "<tr><td valign=top><font face=arial>".$result[$i][0]."</font></td><td valign=top><font face=arial><a href=\"admin_forums.php?do=editforum&id=".$result[$i][0]."\">".$result[$i][1]."</a></font></td>\n";

echo "<td valign=top><font face=arial>".$result[$i][2]."</font></td></tr>";

echo "<tr><td colspan=3><hr></td></tr>";
}

?>

</table>

<?

}

include('footer.php');

?>



