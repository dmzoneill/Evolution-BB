<?php

#######################################################################################################

/*
Copyright � 2001 Martin Galpin & Kris Bailey

This file is part of EvoBB.

evoBB is free software that you may download and use.  You may modify this
code as much as you like but you may not re-distribute it.  We wish for
this software to be free but we do not wish to have it distributed by
anyone other than the evobb team.  You may not sell evobb software but you
may sell the service of installing and/or configuring it.  If you do sell
the service of installing and/or configuring evobb software you must
inform whomever is employing you for this service that evobb is free and
that they are not paying for evobb but for your service.

And as is with GNU licensed software this software (evoBB) does not come
with any warranty whatsoever, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. (sound framiliar?)
*/


#######################################################################################################


require('style.php');
require('track.php');
require('functions.php');
require('connect.php');


if(!$mode) {

require('header.php');


?>

<table border=0 cellPadding=0 cellSpacing=0 width="<?php echo $style->tbl_width; ?>">
<tr bgcolor="<?php echo $style->tableoutline; ?>">
<td>


<table border=0 width=100% cellspacing=1 cellpadding=4>
<tr>

<th bgcolor="<?php echo $style->tbl_header; ?>">
<?php $style->headertextout("Documentation"); ?>
</th>
</tr>
<tr>

<td bgcolor="<?php echo $style->tbl1color;?>">
<table cellpadiing=15><tr><td>
<?php $style->textout("<h2>Help Topics</h2>
<a href=#evoCode>evoCode</a><br>
<a href=#HTML>HTML in your messages</a><br>
<a href=#LostPasswords>Lost Your Password</a><br><br><br>
<A NAME=evoCode>");?>
</td></tr></table>


</td></tr>
<tr>

<th bgcolor="<?php echo $style->tbl_header; ?>">
<?php $style->headertextout("EvoCode"); ?>
</th>
</tr>
<tr>

<td bgcolor="<?php echo $style->tbl1color;?>">
<table cellpadiing=15><tr><td>
<?php $style->textout("
<h2>evoCode</h2>
Evolution BB has it's own replacment for HTML, called evoCode. It allows you to present messages how you would like, with common tags such as &lt;b>.<br>
Below is a list of the evoCode, and the HTML equivilent.<br><br>");?>
<center>
<table width=40% border=0>
<tr>
<th width=50%><?php $style->textout("<b>evoCode</b>");?></th>
<th width=50%><?php $style->textout("<b>HTML</b>");?></th>
</tr>
<tr>
<th width=50%><?php $style->textout(":b: :/b:");?></th>
<th width=50%><?php $style->textout("&lt;b> &lt;/b>");?></th>
</tr>
<tr>
<th width=50%><?php $style->textout(":i: :/i:");?></th>
<th width=50%><?php $style->textout("&lt;i> &lt;/i>");?></th>
</tr>
<tr>
<th width=50%><?php $style->textout(":u: :/u:");?></th>
<th width=50%><?php $style->textout("&lt;u> &lt;/u>");?></th>
</tr>
<tr>
<th width=50%><?php $style->textout(":img: :/img:");?></th>
<th width=50%><?php $style->textout("&lt;img src=>");?></th>
</tr>
</table>
</td></tr></table>
</td></tr>
<tr>

<th bgcolor="<?php echo $style->tbl_header; ?>">
<?php $style->headertextout("HTML in posts :"); ?>
</th>
</tr>
<tr>

<td bgcolor="<?php echo $style->tbl1color;?>">
<table cellpadiing=15><tr><td>
</a>
<?php $style->textout("
<a NAME=HTML>
<h2>HTML</h2>
You may use HTML in your posts, permitting the administrator has enabled it for his/hers forum. Please be careful about the syntax of your HTML, because erroroneus HTML can lead to moderators / adminstrators editing your posts.
</a>");?>
</td></tr></table>

</td></tr>
<tr>

<th bgcolor="<?php echo $style->tbl_header; ?>">
<?php $style->headertextout("Lost Passwords :"); ?>
</th>
</tr>
<tr>

<td bgcolor="<?php echo $style->tbl1color;?>">
<table cellpadiing=15><tr><td>
<?php $style->textout("
<A NAME=LostPasswords>
<h2>Lost Passwords</h2>
If you have lost or forgotten your password, you may use the 'Lost Password' link on the <a href=login.php>login</a>
page. This will require you to input the email address you signed up with, and your username.
</a>

");?>
</td></tr></table>
</td>
</tr>
</table>
</td></tr></table><br>

<?
include('footer.php');



} elseif($mode) {
$style = new Style;
$style->Body();
?>
<table border=0 cellpadding=0 cellspacing=0 width=98%>
<tr bgcolor=black><tr bgcolor=black>
<td><table width=100% border=0 cellpadding=1 cellspacing=1>
<tr bgcolor=<?php echo $style->tbl2color;?>>
<td>
<?

	switch($page) {
		case "postpoll":
			$style->textout("<font size=1>From here you attach polls to your topic. This is a simple where users
			vote on one of five choices you specify above.<br><br>
			<b>Points to note:</b><br>
			<li>Leaving a option blank means it will not be enetered into the poll.
			<li>Each user has <b>one</b> single vote.</font>");
		break;
		case "post":
			$style->textout("<font size=1>You can post new topics or replies here.<br><br>
			<b>Points to note:</b><br>
			<li>You may edited your posts later on.
			<li>HTML, evoCode and smilies are unabled by the Administrator. (check forum rules).
			<li>Post Metrics are wizards for evoCode. Click on them and find out :)</font>");
		break;
	}
}
?>
</td>
</tr>
</table></td>
</tr></table>
<?


?>




