<?php


#######################################################################################################

/*
Copyright � 2001 Martin Galpin & Kris Bailey

This file is part of EvoBB.

evoBB is free software that you may download and use.  You may modify this
code as much as you like but you may not re-distribute it.  We wish for 
this software to be free but we do not wish to have it distributed by 
anyone other than the evobb team.  You may not sell evobb software but you
may sell the service of installing and/or configuring it.  If you do sell
the service of installing and/or configuring evobb software you must 
inform whomever is employing you for this service that evobb is free and
that they are not paying for evobb but for your service.

And as is with GNU licensed software this software (evoBB) does not come 
with any warranty whatsoever, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. (sound framiliar?)
*/


#######################################################################################################


require('track.php');
require('functions.php');
require('connect.php');
require('header.php');
require('vars.php');



###################################
########### topic replying now ####
###################################

if(chthread($userid, $forumid, $groupid, $topicid)=="0") {
dead("auth");
}




if ($step=="reply"){



?>

<form method=post action="<?php echo $PHP_SELF;?>">
<input type=hidden name=groupid value="<?php echo $groupid;?>">
<input type=hidden name=forumid value="<?php echo $forumid;?>">
<input type=hidden name=topicid value="<?php echo $topicid;?>">
<table border=0 cellPadding=0 cellSpacing=0 width="<?php echo $style->tbl_width; ?>">
<tr>
<td><?php $style->textout(printbreadcrumbtrail($forumid)." > <a href=viewtopic.php?groupid=$groupid&forumid=$forumid&topicid=$topicid&title=$subject>".rawurldecode($subject)."</a> > Reply");?></td>
</tr>
<tr bgcolor="<?php echo $style->tableoutline; ?>">
<td><table border=0 width=100% cellspacing=1 cellpadding=4>


<?php

$groupname = $stream->do_query("select title from evo_groups where auto = '$groupid'", "one");
$forumname = $stream->do_query("select title from evo_forums where auto = '$forumid'", "one");
$subject = $stream->do_query("select topic_subject from evo_topics_$forumid where topic_id = '$topicid'", "one");
$closed = $stream->do_query("select closed from evo_topics_$forumid where topic_id = '$topicid'", "one");
if($closed=="1") {
dead("closed");
}

if (!$loggedin && $u && $p!=""){

                if(auth($u, $p)==1){

                require('track.php');

                } else {

                unset($loggedin);

                }

}



if ($loggedin){



if ($tryagain){

$post = $post;

} else {

$post = rawurlencode(stripslashes($post));

}

$time = time();

#### check to see wheather we need to notify a user
$notify = $stream->do_query("select notify from evo_posts_$forumid where topic_id = '$topicid'", "one");
if($notify=="1") {
notifyuser($userid, $topicid, $forumid, $groupid);
}
#####

resetread($forumid, $topicid);
        $ip = getenv("REMOTE_ADDR");
        $sql1 = $stream->do_query("INSERT INTO evo_posts_$forumid (topic_id, post_id, poster_id, post, time, something, ip) VALUES ('$topicid', '', '$userid', '$post', '$time', '', '$ip')", "one");
        $sql2 = $stream->do_query("update evo_users set num_posts = num_posts+1 where id = '$userid'", "one");
        $sql3 = $stream->do_query("update evo_forums set last = '$time|$userid' where auto = '$forumid'", "one");
        $sql4 = $stream->do_query("update evo_topics_$forumid set time = '$time' where topic_id = '$topicid'", "one");
?>
<tr>

<td bgcolor="<?php echo $style->tbl_header; ?>"  colspan=2 align=center>
<?php $style->headertextout("New Reply Created!");?>
<script language=javascript>
<!--
setTimeout("document.location.href='viewtopic.php?groupid=<?php echo $groupid;?>&forumid=<?php echo $forumid;?>&topicid=<?php echo $topicid;?>&<?php echo uniqid(0);?>';", 2000);
//-->
</script>
</td>
</tr>

<tr>
<td colspan=2 bgcolor=<?php echo $style->tbl1color;?> align=center><?php $style->textout("<a href=\"viewtopic.php?groupid=$groupid&forumid=$forumid&topicid=$topicid'\">Click here to view it!</a>");?></td>
</tr>

<?php



} else {



if ($tryagain){

$post = rawurldecode($post);

}



?>
<tr>

<th bgcolor="<?php echo $style->tbl_header; ?>" colspan=2 align=center><?php $style->textout("New Topic"); ?></th>

</tr>

<tr>

<th bgcolor="<?php echo $style->tbl1color; ?>" colspan=2 align=center><?php $style->textout("Authentification Failure: Please check your username and password."); ?></th>

</tr>

<tr>

<td align=right bgcolor="<?php echo $style->tbl2color; ?>"><?php $style->textout("Username:"); ?></td>

<td bgcolor="<?php echo $style->tbl1color; ?>"><input type=text name=u value="<?php echo $u;?>"></td>

</tr>

<tr>

<td bgcolor="<?php echo $style->tbl2color; ?>" align=right><?php $style->textout("Password:"); ?></td>

<td bgcolor="<?php echo $style->tbl1color; ?>"><input type=password name=p></td>

</tr>

<tr>

<td bgcolor="<?php echo $style->tbl2color; ?>" align=right><?php $style->textout("Try Again?");?></td>

<td bgcolor="<?php echo $style->tbl1color; ?>"><input type=submit value="Yes" name=tryagain><input type=hidden name=step value="reply"><input type=hidden name=post value="<?php echo rawurlencode(stripslashes($post));?>"></td>

</tr>


<?php





}





?>

</table></td></tr></table></form></td></tr></table>

<?php



} else {



?>

<form name="xerox" method=post action="<?php echo $PHP_SELF;?>">

<input type=hidden name=groupid value="<?php echo $groupid;?>">

<input type=hidden name=forumid value="<?php echo $forumid;?>">

<input type=hidden name=topicid value="<?php echo $topicid;?>">

<input type=hidden name=step value="reply">
<?php

        $subject = $stream->do_query("select topic_subject from evo_topics_$forumid where topic_id = '$topicid'", "one");

?>

<table border=0 cellPadding=0 cellSpacing=0 width="<?php echo $style->tbl_width; ?>">
<tr>
<td><?php $style->textout(printbreadcrumbtrail($forumid)." > <a href=viewtopic.php?groupid=$groupid&forumid=$forumid&topicid=$topicid&title=$subject>".rawurldecode($subject)."</a> > Reply");?></td>
</tr>

<tr bgcolor="<?php echo $style->tableoutline; ?>">

<td><table border=0 width=100% cellspacing=1 cellpadding=4>
<tr>

<th bgcolor="<?php echo $style->tbl_header; ?>" colspan=2 align=center><?php $style->textout("Reply"); ?></th>

</tr>


<?php

if (!$loggedin){

?>


<tr>

<td bgcolor="<?php echo $style->tbl2color; ?>" align=right><?php $style->textout("Username:"); ?></td>

<td bgcolor="<?php echo $style->tbl1color; ?>"><input type=text name=u></td>

</tr>

<tr>

<td bgcolor="<?php echo $style->tbl2color; ?>" align=right><?php $style->textout("Password:"); ?></td>

<td bgcolor="<?php echo $style->tbl1color; ?>"><input type=password name=p></td>

</tr>

<?php

} else {

?>

<tr>

<td bgcolor="<?php echo $style->tbl2color; ?>" align=right><?php $style->textout("Username:"); ?></td>

<td bgcolor="<?php echo $style->tbl1color; ?>"><?php $style->textout("$tusername");?></td>

</tr>

<?php

}

?>

<tr>

<td bgcolor="<?php echo $style->tbl2color; ?>" align=right valign=top><?php $style->textout("Post:"); ?><br><br><br>

<?

if($allowhtml==1) {
$style->textout("<font size=1><b>HTML</b> is allowed</font><br>");
} else {
$style->textout("<font size=1><b>HTML</b> is disallowed</font><br>");
}

if($allowbbcode==1) {
$style->textout("<font size=1><b>BBcode</b> is allowed</font><br>");
} else {
$style->textout("<font size=1><b>BBcode</b> is disallowed</font><br>");
}

if($usesmiles==1) {
$style->textout("<font size=1><b>Smiles</b> are enabled</font><br>");
} else {
$style->textout("<font size=1><b>Smiles</b> are disabled</font><br>");
}

?>

</td>
<td bgcolor="<?php echo $style->tbl1color; ?>">

<table cellspacing="0" cellpadding="5"><tr><td width=250>
<textarea cols=50 rows=10 name=post></textarea>
</td><td width=150>
<?php include('smilepost.php'); ?>
</td></tr></table>

</td>
</tr>
<tr>

<td bgcolor="<?php echo $style->tbl2color; ?>" align=right><?php $style->textout("Reply?"); ?></td>

<td bgcolor="<?php echo $style->tbl1color; ?>"><input type=submit value="Submit">&nbsp;<input type=reset value="Reset"></td>

</tr>

<?php



?>

</table></td></tr></table></tr></td></table></form>

<?php

}

echo "<br>";
include('footer.php');




?>

