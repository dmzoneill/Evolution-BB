<?php

#######################################################################################################

/*
Copyright � 2001 Martin Galpin & Kris Bailey

This file is part of EvoBB.

evoBB is free software that you may download and use.  You may modify this
code as much as you like but you may not re-distribute it.  We wish for
this software to be free but we do not wish to have it distributed by
anyone other than the evobb team.  You may not sell evobb software but you
may sell the service of installing and/or configuring it.  If you do sell
the service of installing and/or configuring evobb software you must
inform whomever is employing you for this service that evobb is free and
that they are not paying for evobb but for your service.

And as is with GNU licensed software this software (evoBB) does not come
with any warranty whatsoever, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. (sound framiliar?)
*/


#######################################################################################################

if ($id){
$member = $id;
}

require_once("connect.php");
require_once('track.php');
require_once('style.php');
##########################################
# stats ##################################
##########################################
$users = $stream->do_query("select id, username from evo_users order by id DESC", "array");
$id = $users[0][0];
$user = $users[0][1];
$num_users = count($users);
$topprint = "<b>Current Users Count</b>: $num_users<br>";
$topprint .= "Welcome to our newest member, <a href=members.php?do=profile&id=$id>$user</a><br>";
########################################
# check for new private messages #######
########################################
if ($loggedin){
$new = count($stream->do_query("select auto from evo_pms where opened = '0' and owner = '$userid'", "array"));
$loginprint = "Welcome <b>$tusername</b>.";
$msgprint = "[ $tusername ::  You have <b>$new</b> new <a href=\"inbox.php?$uniq\">messages</a> ::  <a href=\"logout.php\">Logout</a> ]";
} else {
$msgprint = "Username:&nbsp;&nbsp;<input type=text name=u size=10>&nbsp;&nbsp;&nbsp;&nbsp;Password:&nbsp;&nbsp;<input type=password name=p size=10> <input type=submit name=go value=Login> <a href=lostpass.php>Lost Password</a>";
}
#########################################
# count topics etc ######################
###################################
$tpcount = tpcount();
$tpcount = explode("|", $tpcount);
#########################################
# speed enhancment ######################
##################################
ob_start("ob_gzhandler");
#########################################
$mhf = $stream->do_query("SELECT HEADER, META FROM evo_hmf", "row");
#########################################
#########################################
###### make new instance of the style class
#########################################
$style = new Style;
########################################
# start the html off   #################
########################################
$style->PageHeader();
########################################
#### body tag information ##############
########################################
########
$style->Body();
########################################
####### display the top of the forum ###
########################################
############
$style->ForumHeader();

#########################################
######## check to see if the user is banned  ####
#########################################

#IP ban
$bans = $stream->do_query("select ip from evo_bans", "array");
$userip = getenv("HTTP_X_FORWARDED_FOR");
$userhost = gethostbyaddr($userip);

for($i=0;$i<count($bans);$i++) {
$user = $bans[$i];
$address = $user[0];
if(ereg($address, $userip)) {
dead("banned");
}
if(ereg($address, $userhost)) {
dead("banned");
}
}

#user ban
$rank = $stream->do_query("select rank from evo_users where id = '$userid'", "one");
if($rank=="1") {
dead("banned");
}

?>
