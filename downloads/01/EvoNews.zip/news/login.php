<?php

/* 
EvoNews written by neiller at evobb dot com (neiller@evobb.com)

Also available EvoBB co-producer with Xavic and fod 
available for download @ http://www.evobb.com...

Note: you can edit below this but its not advised, 
once you have installed please make sure to delete install.php or at least chmod it to 111..
If stuff is editable it will say it next to the code in the comments..

Make sure to edit the conf.php before you start installing your EvoNews :)

NB : once logged in change your password :)
*/


if($type=="yes"){
$blah34 = "<center>Not logged in<br>";
}
else {
$blah34 = "<br>";
}


if(!$page){

print "<br><br>$blah34<br><br><center><table border=0 cellpadding=5 width=630><tr><td valign=top width=100%>
<center><h3>Please login ....</h3><form method=post action=\"login.php?page=doit\">
<table border=0 width=400>
<tr>
<td align=right>Username:</td>
<td><input type=text name=userlogin></td>
</tr>
<tr>
<td align=right>Password:</td>
<td><input type=password name=passlogin></td>
</tr>
<tr>
<td align=right>&nbsp;</td>
<td><input type=submit value=\"Login\">
<input type=\"hidden\" name=\"step\" value=\"auth\">
</td>
</tr>
</table>
</form>
</center>";

}



if($page=="doit"){

require("conf.php");
include("connect.php");


$idbrowse = md5(getenv('REMOTE_ADDR').getenv('USER_AGENT'));
$howmanyrows = mysql_query("SELECT * FROM news_cookie");
$get = mysql_num_rows($howmanyrows);
$exist = "SELECT * FROM news_cookie WHERE browsingid='$idbrowse'";

if(mysql_query($exist,$connect)){
mysql_query("DELETE FROM news_cookie");
}


$whattime = time();
$timer = $whattime-300;
$delete = "DELETE from news_cookie where timeout>=$timer";
mysql_query($delete,$connect);


$dothepass = md5($passlogin);
print "<br><br><br><br><center>Authorization steps in process ....";
$sql = "INSERT INTO news_cookie (browsingid, username, password, timeout) values ('$idbrowse', '$userlogin', '$dothepass','$whattime')";
mysql_query($sql, $connect);
print "<body onLoad=\"javascript:document.location.href='admin.php?'\">";

}


?>

</body
</html>