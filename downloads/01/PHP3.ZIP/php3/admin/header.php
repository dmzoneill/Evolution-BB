<?php
#######################################################################################################

/*
Copyright � 2001 Martin Galpin & Kris Bailey

This file is part of EvoBB.

evoBB is free software that you may download and use.  You may modify this
code as much as you like but you may not re-distribute it.  We wish for
this software to be free but we do not wish to have it distributed by
anyone other than the evobb team.  You may not sell evobb software but you
may sell the service of installing and/or configuring it.  If you do sell
the service of installing and/or configuring evobb software you must
inform whomever is employing you for this service that evobb is free and
that they are not paying for evobb but for your service.

And as is with GNU licensed software this software (evoBB) does not come
with any warranty whatsoever, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. (sound framiliar?)
*/


#######################################################################################################

if (!$thistitle){$thistitle="Administration";}

$phpex = ".php3";


?>
<html>
<head>
<title>Administration Login</title>
</head>
<body bgcolor=white topmargin=2 marginwidth=2 marginheight=2 leftmargin=2 text="#000000" link="#000000" vlink="#000000" alink="#000000">
<center>
<table border=0 cellPadding=0 cellSpacing=0 width="90%">
<tr bgcolor="#000000">
<td><table border=0 width=100% cellspacing=1 cellpadding=4>
<tr>
<td bgcolor="<?php echo $tbl_bg_color;?>" align=center><B><FONT FACE="Verdana" SIZE="2" color="<?php echo $tbl_text_color;?>"><?php echo $thistitle;?></FONT></B>
</td>
</tr>

<tr>
<td align=center bgcolor="<?php echo $tbl_bg_color2;?>"><font color="<?php echo $tbl_text_color2;?>">
<center>