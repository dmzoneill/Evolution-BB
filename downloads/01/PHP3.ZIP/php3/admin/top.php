<?php
#######################################################################################################

/*
Copyright � 2001 Martin Galpin & Kris Bailey

This file is part of EvoBB.

evoBB is free software that you may download and use.  You may modify this
code as much as you like but you may not re-distribute it.  We wish for
this software to be free but we do not wish to have it distributed by
anyone other than the evobb team.  You may not sell evobb software but you
may sell the service of installing and/or configuring it.  If you do sell
the service of installing and/or configuring evobb software you must
inform whomever is employing you for this service that evobb is free and
that they are not paying for evobb but for your service.

And as is with GNU licensed software this software (evoBB) does not come
with any warranty whatsoever, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. (sound framiliar?)
*/


#######################################################################################################


?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
        <title>Untitled</title>
</head>

<BODY text=#000000 vLink=#333333 aLink=#0066cc link=#000000>



<table cellspacing="0" cellpadding="0" width="100%" height="100%">
<tr height="5">
<td height="5" bgcolor="#FFC007" width="100%"><!------hhhh-----></td>
</tr>

<tr height="47" width="100%">
<td width="240" height="47" valign="top" background="../images/boxed.gif">
<a href="../fdisplay.php3" target="_blank"><img src="../images/evosmall.gif" border="0"></a></td>
<td background="../images/boxed.gif" width="*">

<!----- if you need to put shit in to this ie.text, put it here----->



</td>
</tr>
<tr height="5">
<td background="../images/boxed.gif" width="100%"><!----------ggggggg------> </td>



</tr>
</table>




</body>
</html>